﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WareHouse_Managment.Migrations
{
    /// <inheritdoc />
    public partial class MyDBContext : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
