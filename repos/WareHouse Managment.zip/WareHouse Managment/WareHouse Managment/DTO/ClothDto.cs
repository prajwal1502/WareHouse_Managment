﻿namespace WareHouse_Managment.DTO
{
    public class ClothDto
    {
        public int Id { get; set; } // Id of the Cloth item
        //public double EAN { get; set; }
        //public double EpcNo { get; set; }
        //public string Type { get; set; }
        //public string Size { get; set; }
        //public DateTime InWord { get; set; }
        //public DateTime OutWord { get; set; }
        //public bool IsActive { get; set; }
    }
}